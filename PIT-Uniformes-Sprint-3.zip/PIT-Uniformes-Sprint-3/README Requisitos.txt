Requisitos Sprint 3:
1. Sistema deverá permitir a escola/fornecedor de  atualizar o site de uniformes(dois em um só); Victor e João Mateus
2. Sistema deverá permitir a recuperação de senha de escola parceiras/fornecedores(dois requisitos em um só); Kaio Mayer - João Elias
3. Página de contato; João Tadeu
4. Página de sobre nós; João Tadeu
5. Sistema deverá conter detalhes sobre as peças de roupa; João Elias e Tadeu
6. O sistema deverá permitir a consulta de estoques de uniformes. Rafael e Victor
