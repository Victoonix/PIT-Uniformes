<!DOCTYPE html>
<html>
<head>
  <title>RVK STORE - Home</title>
  <meta charset='utf-8'>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css\style1.css">
</head>
<body>

<header class="header">
  <a href="../Pagina Inicial/index.html"><img src="assets/imgs/logo.png" alt="logo-onebitcode" class="logo-onebitcode"></a>
  <div class="buttons">
    <a href="pagsCadastro/pagCadUniforme.html" class="buttonHeader1">Registrar uniformes</a>
  </div>
</header>
<main>
    
    <button class="uniforme">
      <img src="assets/imgs/MD_imgSemImagem.png" class="uni">
      <p>camisa 1</p>
    </button>
    <button class="uniforme">
      <img src="assets/imgs/MD_imgSemImagem.png" class="uni">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi voluptate commodi, quisquam necessitatibus cupiditate veritatis inventore aut aliquid ducimus quas alias hic ipsum, velit laudantium voluptatibus deleniti reiciendis id eligendi.</p>
    </button>
    <button  class="uniforme">
      <img src="assets/imgs/MD_imgSemImagem.png" class="uni">
      <p>camisa 3</p>
    </button>
</main>
<main>
  <button  class="uniforme">
    <img src="assets/imgs/MD_imgSemImagem.png" class="uni">
    <p>camisa 4</p>
  </button>
    <button  class="uniforme">
    <img src="assets/imgs/MD_imgSemImagem.png" class="uni">
    <p>camisa 5</p>
  </button>
  
    <button  class="uniforme">
    <img src="assets/imgs/MD_imgSemImagem.png" class="uni">
    <p>camisa 6</p>
  </button>
</main>